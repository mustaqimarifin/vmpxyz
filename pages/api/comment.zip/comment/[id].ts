import type { NextApiRequest, NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import prisma from 'lib/prisma';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const session = await getSession( { req } );

  const { id, userId } = req.query;
  const { name } = session.user;

  const entry = await prisma.comment.findUnique( {
    where: {
      id: String( id )
    }
  } );

  if ( req.method === 'GET' ) {
    return res.json( { entry } );
  }

  if ( !name || name !== entry.userId ) {
    return res.status( 403 ).send( 'Unauthorized' );
  }

  if ( req.method === 'DELETE' ) {
    await prisma.comment.delete( {
      where: {
        id: String( id )
      }
    } );

    return res.status( 204 ).json( {} );
  }

  return res.send( 'Method not allowed.' );
}
