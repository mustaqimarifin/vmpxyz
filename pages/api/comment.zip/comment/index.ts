import type { NextApiRequest, NextApiResponse } from 'next';
import { nanoid } from 'nanoid'
import { getSession } from 'next-auth/react';
import prisma from 'lib/prisma';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    const postId = req.query
    const { slug, text } = req.body
    // Query the pages table in the database where url equals the request params url.
    const entries = await prisma.comment.findMany( {
      include: {
        post: {
          select: {
            slug: true
          },
        },
        user: {
          select: {
            name: true, image: true
          },
        }
      },
      where: { post: slug },
      orderBy: [ { id: 'desc' } ],
      take: 10,
    } )

    if ( req.method === 'GET' ) {
      return res.json(
        entries.map( ( entry ) => ( {
          id: entry.id.toString(),
          name: entry.user.name,
          image: entry.user.image,
          text: entry.text,
          slug: entry.post.slug,
          created_at: entry.created_at.toString(),
        } ) )

      )
    }


    const session = await getSession( { req } )
    const { name, image, email } = session.user
    if ( !session ) {
      return res.status( 403 ).send( 'Unauthorized' )
    }

    if ( req.method === 'POST' ) {
      const newEntry = await prisma.comment.create( {
        include: {
          user: {
            select: {
              name: true,
              image: true,
            },
          },
          post: {
            select: {
              slug: true,
            },
          },
        },
        data: {
          id: nanoid(),
          text,
          user: { connect: { email } },
          post: { connect: { id: String( postId ) } },

        },
      } )

      return res.status( 200 ).json( {

        id: newEntry.id.toString(),
        text: newEntry.text,
        name: newEntry.user.name,
        image: newEntry.user.image,
        slug: newEntry.post.slug,
        created_at: newEntry.created_at.toString(),
      } )
    }

    return res.send( 'Method not allowed.' )
  } catch ( e ) {
    return res.status( 500 ).json( { message: e.message } );
  }
}
