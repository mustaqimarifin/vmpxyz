import { useState, useEffect } from 'react';
import useSWR from 'swr';
import fetcher from 'lib/fetcher';

export default function useComments() {
  const [text, setText] = useState('');
  const [slug, setSlug] = useState(null);

  const { data: comments, mutate } = useSWR(
    () => {
      const query = new URLSearchParams({ slug });
      return `/api/comment?${query.toString()}`;
    },
    fetcher,
    {
      fallbackData: []
    }
  );

  useEffect(() => {
    const slug = window.location.href.substring(
      window.location.href.lastIndexOf('/') + 1
    );
    setSlug(slug);
  }, []);

  const onSubmit = async (e) => {
    e.preventDefault();

    const res = await fetch('/api/comment', {
      body: JSON.stringify({ slug, text }),
      headers: {
        'Content-Type': 'application/json'
      },
      method: 'POST'
    });

    const { error } = await res.json();
    if (error) {
      return;
    }

    setText('');
    await mutate();
  };

  const onDelete = async (e: { preventDefault: () => void }) => {
    e.preventDefault();
    try {
      await fetch('/api/comment', {
        method: 'DELETE',
        body: JSON.stringify({ slug, comments }),
        headers: {
          'Content-Type': 'application/json'
        }
      });
      await mutate();
    } catch (err) {
      console.log(err);
    }
  };

  return { text, setText, comments, onSubmit, onDelete };
}
