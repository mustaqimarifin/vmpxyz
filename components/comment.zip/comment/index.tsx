import CommentForm from './form';
import CommentList from './list';
import useComments from 'hooks/useComment';

function Comment(comment) {
  const { text, setText, comments, onSubmit, onDelete } = useComments();

  return (
    <div key={comment.id} className="mt-20">
      <CommentForm onSubmit={onSubmit} text={text} setText={setText} />
      <CommentList comments={comments} onDelete={onDelete} />
    </div>
  );
}

export default Comment;
