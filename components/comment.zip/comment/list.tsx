import { format } from 'date-fns';
import { useSession } from 'next-auth/react';
import Image from 'next/image';
import useSWR, { useSWRConfig } from 'swr';

function CommentList({ user, comment, comments }) {
  const { mutate } = useSWRConfig();
  const onDelete = async (e) => {
    e.preventDefault();

    await fetch(`/api/comment/${comment.id}`, {
      method: 'DELETE'
    });

    mutate('/api/comment');
  };

  return (
    <div className="w-full space-y-6 mt-10">
      {comments.map((comment) => {
        return (
          <div key={comment.created_at} className="flex space-x-4">
            <div className="flex-shrink-0">
              <Image
                src={comment.image}
                alt={comment.name}
                width={40}
                height={40}
                className="rounded-full"
              />
            </div>

            <div className="flex-grow">
              <div className="flex space-x-2">
                <b>{comment.name}</b>
                <time className="text-gray-400">
                  {format(
                    new Date(comment.created_at),
                    "d MMM yyyy 'at' h:mm bb"
                  )}
                </time>
                {user && comment.name === user.name && (
                  <button
                    className="text-gray-400 hover:text-red-500"
                    onClick={() => onDelete(comment)}
                    aria-label="Close"
                  >
                    x
                  </button>
                )}
              </div>

              <div>{comment.text}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default CommentList;
